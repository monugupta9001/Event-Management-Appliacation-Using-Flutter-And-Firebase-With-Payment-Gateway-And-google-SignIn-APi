import 'package:eventnest1/admin/homeadmin.dart';
import 'package:eventnest1/admin/ticket.dart';
import 'package:eventnest1/screens/booking.dart';
import 'package:eventnest1/screens/bottombar.dart' show Bottombar;
import 'package:eventnest1/screens/profile.dart';
import 'package:eventnest1/screens/signup.dart' show Signup;
import 'package:eventnest1/screens/splash.dart' show Splash;
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart' show Stripe;

import 'admin/adminmng.dart' show AdminProfileManagement;
import 'admin/uploadev.dart' show Uploadev;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Stripe.publishableKey = "pk_test_51QzIQ0H1gD5Fk8cPumP7CkvxmkIMMihXcFI07q3JBlUZs2gSVoSaaizk6s84c9nbjEbKmeAqE9QutkMgNfag9RGC00UKNf6nCD";

  try {
    await Firebase.initializeApp();
    print("Connection Successful");
  } catch (e) {
    print("Connection not Successful: $e");
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EventNest',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: const ColorScheme(
          brightness: Brightness.light,
          primary: Color(0xFF0066CC),
          onPrimary: Colors.white,
          secondary: Color(0xFFFFB400),
          onSecondary: Colors.white,
          background: Color(0xFFF4F5F7),
          onBackground: Color(0xFF212121),
          surface: Colors.white,
          onSurface: Color(0xFF212121),
          error: Color(0xFFCF6679),
          onError: Colors.white,
        ),
        buttonTheme: const ButtonThemeData(
          buttonColor: Color(0xFF0066CC),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0066CC),
        ),
      ),
      home: Splash(),
      // Uncomment one of the following for testing:
      // home: Bottombar(),
      // home: AdminProfileManagement(),
      // home: Uploadev(),
    );
  }
}
