import 'package:flutter/material.dart';
import '../services/database.dart';

class ViewUserDataScreen extends StatefulWidget {
  final String userId;
  final String name;
  final String email;

  const ViewUserDataScreen({
    super.key,
    required this.userId,
    required this.name,
    required this.email,
  });

  @override
  State<ViewUserDataScreen> createState() => _ViewUserDataScreenState();
}

class _ViewUserDataScreenState extends State<ViewUserDataScreen> {
  Map<String, dynamic>? userData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  Future<void> fetchUserData() async {
    final data = await DatabaseMeathod().getUserData(widget.userId);
    if (mounted) {
      setState(() {
        userData = data;
        isLoading = false;
      });
    }
  }

  Widget buildInfoTile({required IconData icon, required String label, required String value}) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        leading: Icon(icon, color: Colors.deepPurple),
        title: Text(label, style: const TextStyle(color: Colors.grey, fontSize: 13)),
        subtitle: Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("User Profile"),
        backgroundColor: Colors.deepPurple,
        elevation: 0,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFa18cd1), Color(0xFFfbc2eb)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : userData == null
            ? const Center(
          child: Text(
            "Failed to load user data.",
            style: TextStyle(fontSize: 18, color: Colors.white),
          ),
        )
            : SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 30),
              CircleAvatar(
                radius: 60,
                backgroundColor: Colors.white,
                backgroundImage: userData!['profilePicture'] != null &&
                    userData!['profilePicture'].toString().isNotEmpty
                    ? NetworkImage(userData!['profilePicture'])
                    : null,
                child: userData!['profilePicture'] == null ||
                    userData!['profilePicture'].toString().isEmpty
                    ? const Icon(Icons.person, size: 60, color: Colors.deepPurple)
                    : null,
              ),
              const SizedBox(height: 20),
              Text(
                widget.name,
                style: const TextStyle(
                    fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              Text(
                widget.email,
                style: const TextStyle(fontSize: 16, color: Colors.white70),
              ),
              const SizedBox(height: 20),
              buildInfoTile(
                icon: Icons.phone,
                label: "Phone",
                value: userData?['phone']?.toString().isNotEmpty == true
                    ? userData!['phone']
                    : "No Phone",
              ),
              if (userData?['address'] != null)
                buildInfoTile(
                  icon: Icons.location_on,
                  label: "Address",
                  value: userData!['address'],
                ),
              if (userData?['dob'] != null)
                buildInfoTile(
                  icon: Icons.calendar_today,
                  label: "Date of Birth",
                  value: userData!['dob'],
                ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
