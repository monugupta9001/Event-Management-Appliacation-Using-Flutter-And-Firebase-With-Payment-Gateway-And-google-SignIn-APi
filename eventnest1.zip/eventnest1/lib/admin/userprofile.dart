// import 'package:flutter/material.dart';
// import 'package:eventnest1/services/auth.dart';
//
// class EditUserProfile extends StatefulWidget {
//   final String userId;
//   final String name;
//   final String email;
//
//   const EditUserProfile({
//     Key? key,
//     required this.userId,
//     required this.name,
//     required this.email,
//   }) : super(key: key);
//
//   @override
//   State<EditUserProfile> createState() => _EditUserProfileState();
// }
//
// class _EditUserProfileState extends State<EditUserProfile> {
//   late TextEditingController nameController;
//   late TextEditingController emailController;
//
//   final _formKey = GlobalKey<FormState>();
//   bool isLoading = false;
//
//   @override
//   void initState() {
//     super.initState();
//     nameController = TextEditingController(text: widget.name);
//     emailController = TextEditingController(text: widget.email);
//   }
//
//   @override
//   void dispose() {
//     nameController.dispose();
//     emailController.dispose();
//     super.dispose();
//   }
//
//   Future<void> updateProfile() async {
//     if (!_formKey.currentState!.validate()) return;
//
//     setState(() => isLoading = true);
//
//     try {
//       final success = await AuthMeathod().updateUserProfile(
//         nameController.text.trim(),
//         emailController.text.trim(),
//       );
//
//       if (success) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Profile updated successfully!')),
//         );
//         Navigator.pop(context);
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Failed to update profile.')),
//         );
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Error: $e')),
//       );
//     } finally {
//       setState(() => isLoading = false);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xfff4ecff),
//       appBar: AppBar(
//         backgroundColor: const Color(0xFF6C5CE7),
//         title: const Text('Edit Profile'),
//         elevation: 4,
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(20),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             children: [
//               // Gradient Avatar
//               Container(
//                 padding: const EdgeInsets.all(4),
//                 decoration: const BoxDecoration(
//                   shape: BoxShape.circle,
//                   gradient: LinearGradient(
//                     colors: [Color(0xFFE0C3FC), Color(0xFF8EC5FC)],
//                     begin: Alignment.topLeft,
//                     end: Alignment.bottomRight,
//                   ),
//                 ),
//                 child: const CircleAvatar(
//                   radius: 50,
//                   backgroundColor: Colors.white,
//                   child: Icon(Icons.person, size: 50, color: Color(0xFF6C5CE7)),
//                 ),
//               ),
//               const SizedBox(height: 24),
//
//               // Name field
//               Container(
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(14),
//                   boxShadow: const [
//                     BoxShadow(
//                       color: Colors.black12,
//                       blurRadius: 6,
//                       offset: Offset(0, 3),
//                     ),
//                   ],
//                 ),
//                 child: TextFormField(
//                   controller: nameController,
//                   decoration: InputDecoration(
//                     labelText: 'Full Name',
//                     border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(14),
//                       borderSide: BorderSide.none,
//                     ),
//                     prefixIcon: const Icon(Icons.person),
//                     filled: true,
//                     fillColor: Colors.white,
//                   ),
//                   validator: (value) => value!.trim().isEmpty ? 'Name is required' : null,
//                 ),
//               ),
//               const SizedBox(height: 20),
//
//               // Email field
//               Container(
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(14),
//                   boxShadow: const [
//                     BoxShadow(
//                       color: Colors.black12,
//                       blurRadius: 6,
//                       offset: Offset(0, 3),
//                     ),
//                   ],
//                 ),
//                 child: TextFormField(
//                   controller: emailController,
//                   decoration: InputDecoration(
//                     labelText: 'Email',
//                     border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(14),
//                       borderSide: BorderSide.none,
//                     ),
//                     prefixIcon: const Icon(Icons.email),
//                     filled: true,
//                     fillColor: Colors.white,
//                   ),
//                   keyboardType: TextInputType.emailAddress,
//                   validator: (value) {
//                     final email = value!.trim();
//                     if (email.isEmpty) return 'Email is required';
//                     if (!RegExp(r'^[\w\.-]+@[\w\.-]+\.\w{2,4}$').hasMatch(email)) {
//                       return 'Enter a valid email';
//                     }
//                     return null;
//                   },
//                 ),
//               ),
//               const SizedBox(height: 30),
//
//               // Save button
//               SizedBox(
//                 width: double.infinity,
//                 height: 50,
//                 child: ElevatedButton.icon(
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: const Color(0xFF6C5CE7),
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(14),
//                     ),
//                     elevation: 4,
//                   ),
//                   icon: const Icon(Icons.save, color: Colors.white),
//                   label: isLoading
//                       ? const SizedBox(
//                     height: 24,
//                     width: 24,
//                     child: CircularProgressIndicator(
//                       color: Colors.white,
//                       strokeWidth: 2,
//                     ),
//                   )
//                       : const Text(
//                     "Save Changes",
//                     style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),
//                   ),
//                   onPressed: isLoading ? null : updateProfile,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
