import 'dart:convert';
import 'dart:io';

import 'package:eventnest1/services/database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:random_string/random_string.dart';

class Uploadev extends StatefulWidget {
  const Uploadev({super.key});

  @override
  State<Uploadev> createState() => _UploadevState();
}

class _UploadevState extends State<Uploadev> {
  TextEditingController name = TextEditingController();
  TextEditingController price = TextEditingController();
  TextEditingController detail = TextEditingController();
  TextEditingController location = TextEditingController();

  final List<String> eventcategory = ["Music", "Food", "Clothing", "Festival"];
  String? value;

  final ImagePicker _picker = ImagePicker();
  File? selectedImage;

  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay(hour: 10, minute: 00);

  FirebaseMessaging messaging = FirebaseMessaging.instance;

  @override
  void initState() {
    super.initState();
    messaging.requestPermission();
    messaging.subscribeToTopic('events');
  }

  Future<void> getImage() async {
    var image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      selectedImage = File(image.path);
      setState(() {});
    }
  }

  Future<void> _pickDate() async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null) {
      setState(() {
        selectedDate = pickedDate;
      });
    }
  }

  Future<void> _pickTime() async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (pickedTime != null) {
      setState(() {
        selectedTime = pickedTime;
      });
    }
  }

  String formatTimeOfDay(TimeOfDay time) {
    final now = DateTime.now();
    final dateTime = DateTime(
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );
    return DateFormat('hh:mm a').format(dateTime);
  }

  Future<void> sendNotification(String eventName) async {
    const String serverKey =
        'YOUR_FCM_SERVER_KEY'; // Replace with your actual server key

    try {
      await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'key=$serverKey',
        },
        body: jsonEncode({
          "to": "/topics/events",
          "notification": {
            "title": "New Event Uploaded!",
            "body": "$eventName is now available. Check it out!",
          },
        }),
      );
    } catch (e) {
      print("Error sending notification: $e");
    }
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0, bottom: 6),
      child: Text(
        text,
        style: TextStyle(
          color: Colors.black87,
          fontSize: 17,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hint,
    int maxLines = 1,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
        ],
      ),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        style: TextStyle(fontSize: 16),
        decoration: InputDecoration(hintText: hint, border: InputBorder.none),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffa1c4fd),
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(120),
        child: Container(
          padding: EdgeInsets.only(top: 40, left: 20, right: 20, bottom: 25),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF6C5CE7), Color(0xFFA29BFE)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(30),
              bottomRight: Radius.circular(30),
            ),
          ),
          child: Row(
            children: [
              IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
              SizedBox(width: 10),
              Icon(Icons.upload_file, color: Colors.white, size: 28),
              SizedBox(width: 10),
              Text(
                "Upload Event",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: GestureDetector(
                  onTap: getImage,
                  child:
                      selectedImage != null
                          ? ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: Image.file(
                              selectedImage!,
                              height: 160,
                              width: 160,
                              fit: BoxFit.cover,
                            ),
                          )
                          : Container(
                            height: 160,
                            width: 160,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: Colors.grey.shade300),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black12,
                                  blurRadius: 6,
                                  offset: Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.add_a_photo,
                              size: 40,
                              color: Colors.grey,
                            ),
                          ),
                ),
              ),

              _buildLabel("Event Name"),
              _buildInputField(controller: name, hint: "Enter Event Name"),

              _buildLabel("Ticket Price"),
              _buildInputField(controller: price, hint: "Enter Price"),

              _buildLabel("Event Location"),
              _buildInputField(controller: location, hint: "Enter Location"),

              _buildLabel("Category"),
              Container(
                margin: EdgeInsets.only(top: 10),
                padding: EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 6,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: value,
                    hint: Text("Choose Category"),
                    items:
                        eventcategory.map((item) {
                          return DropdownMenuItem(
                            value: item,
                            child: Text(item),
                          );
                        }).toList(),
                    onChanged: (val) => setState(() => value = val),
                  ),
                ),
              ),

              SizedBox(height: 20),
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.calendar_today, color: Colors.deepPurple),
                    onPressed: _pickDate,
                  ),
                  Text(
                    DateFormat("yyyy-MM-dd").format(selectedDate),
                    style: TextStyle(fontSize: 16),
                  ),
                  Spacer(),
                  IconButton(
                    icon: Icon(Icons.access_time, color: Colors.deepPurple),
                    onPressed: _pickTime,
                  ),
                  Text(
                    formatTimeOfDay(selectedTime),
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),

              _buildLabel("Event Details"),
              _buildInputField(
                controller: detail,
                hint: "What will happen at the event?",
                maxLines: 5,
              ),

              SizedBox(height: 30),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 55),
                  backgroundColor: Color(0xff6a5af9),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 5,
                ),
                icon: Icon(Icons.upload_rounded, color: Colors.white),
                label: Text(
                  "Upload Event",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                onPressed: () async {
                  String id = randomAlphaNumeric(10);
                  String firstletter =
                      name.text.trim().substring(0, 1).toUpperCase();

                  Map<String, dynamic> uploadevent = {
                    "name": name.text.trim(),
                    "price": price.text.trim(),
                    "category": value,
                    "serachkey": firstletter,
                    "location": location.text.trim(),
                    "detail": detail.text.trim(),
                    "UpdatedName": name.text.trim().toUpperCase(),
                    "date": DateFormat('yyyy-MM-dd').format(selectedDate),
                    "time": formatTimeOfDay(selectedTime),
                    "image": null,
                  };

                  await DatabaseMeathod().addEvent(uploadevent, id).then((
                    _,
                  ) async {
                    await sendNotification(name.text.trim());
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Row(
                          children: [
                            Icon(Icons.check_circle, color: Colors.white),
                            SizedBox(width: 12),
                            Expanded(
                              child: Text("Event Uploaded Successfully"),
                            ),
                          ],
                        ),
                        backgroundColor: Colors.green,
                        behavior: SnackBarBehavior.floating,
                        action: SnackBarAction(
                          label: 'Dismiss',
                          textColor: Colors.white,
                          onPressed: () {},
                        ),
                        duration: Duration(seconds: 3),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        margin: EdgeInsets.all(16),
                      ),
                    );
                    setState(() {
                      name.clear();
                      price.clear();
                      location.clear();
                      detail.clear();
                      value = null;
                      selectedImage = null;
                    });
                  });
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
