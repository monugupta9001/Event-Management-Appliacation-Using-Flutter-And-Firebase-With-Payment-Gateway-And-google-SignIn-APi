import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:eventnest1/admin/homeadmin.dart';
import 'package:flutter/material.dart';

class Adminsignup extends StatefulWidget {
  const Adminsignup({super.key});

  @override
  State<Adminsignup> createState() => _AdminsignupState();
}

class _AdminsignupState extends State<Adminsignup> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool isLoading = false;

  void _showSnack(String message, {Color color = Colors.red}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: TextStyle(fontSize: 16)),
        backgroundColor: color,
      ),
    );
  }

  void LoginAdmin() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => isLoading = true);

    final enteredId = emailController.text.trim();
    final enteredPassword = passwordController.text.trim();

    try {
      final snapshot = await FirebaseFirestore.instance.collection("Admin").get();
      final adminDoc = snapshot.docs.firstWhere(
            (doc) => doc.data()['id'] == enteredId,
        orElse: () => throw Exception("Admin ID not found"),
      );

      if (adminDoc.data()['password'] == enteredPassword) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => Homeadmin()),
        );
      } else {
        _showSnack("Your password is not correct");
      }
    } catch (e) {
      _showSnack("Your Admin ID is not correct");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(), // dismiss keyboard
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  SizedBox(
                    height: screenHeight * 0.45,
                    width: double.infinity,
                    child: Image.asset(
                      "assets/images/onboarding.png",
                      fit: BoxFit.cover,
                    ),
                  ),

                  const SizedBox(height: 20),
                  Text(
                    "Admin Panel",
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color(0xff6351ec),
                    ),
                  ),
                  const SizedBox(height: 30),

                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text("Admin ID", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                  ),
                  const SizedBox(height: 6),
                  TextFormField(
                    controller: emailController,
                    decoration: InputDecoration(
                      hintText: "Enter Admin ID",
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    validator: (value) =>
                    value == null || value.trim().isEmpty ? "Please enter Admin ID" : null,
                  ),

                  const SizedBox(height: 20),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text("Password", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                  ),
                  const SizedBox(height: 6),
                  TextFormField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: "Enter Password",
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    validator: (value) =>
                    value == null || value.trim().isEmpty ? "Please enter password" : null,
                  ),

                  const SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: isLoading ? null : LoginAdmin,
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.resolveWith<Color>((states) {
                          if (states.contains(MaterialState.pressed)) {
                            return Color(0xff4a3fcc); // darker on press
                          }
                          return Color(0xff6351ec); // normal
                        }),
                        shape: MaterialStateProperty.all(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        elevation: MaterialStateProperty.resolveWith<double>((states) {
                          if (states.contains(MaterialState.pressed)) {
                            return 2; // less elevation when pressed
                          }
                          return 6;
                        }),
                      ),
                      child: isLoading
                          ? CircularProgressIndicator(color: Colors.white)
                          : Text("Log In", style: TextStyle(fontSize: 18, color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
