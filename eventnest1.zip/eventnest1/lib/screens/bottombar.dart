import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:eventnest1/screens/booking.dart';
import 'package:eventnest1/screens/home.dart';
import 'package:eventnest1/screens/profile.dart';
import 'package:flutter/material.dart';

class Bottombar extends StatefulWidget {
  const Bottombar({super.key});

  @override
  State<Bottombar> createState() => _BottombarState();
}

class _BottombarState extends State<Bottombar> {
  late List<Widget> pages;
  late Home home;
  late Booking booking;
  late Profile profile;
  int currentTabindex = 0;

  @override
  void initState() {
    home = Home();
    booking = Booking();

    profile = Profile();
    pages = [home, booking, profile];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: CurvedNavigationBar(
        height: 65,
        backgroundColor: Colors.white,
        color: Color(0xff6351ec),
        animationDuration: Duration(milliseconds: 500),
        onTap: (int index) {
          setState(() {
            currentTabindex = index;
          });
        },
        items: [
          Icon(Icons.home_outlined, color: Colors.white, size: 30),
          Icon(Icons.book, color: Colors.white, size: 30),
          Icon(Icons.person_outline, color: Colors.white, size: 30),
        ],
      ),
      body: pages[currentTabindex],
    );
  }
}
