import 'dart:async' show Timer;

import 'package:eventnest1/screens/signup.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
    startTimer();
  }

  void startTimer() {
    var duration = const Duration(seconds: 5);
    Timer(duration, route);
  }

  void route() {
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const Signup()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        // Separate animation & text
        children: [
          Expanded(
            child: Center(
              child: Lottie.asset(
                "assets/animation/splashold.json",
                height: 300,
                width: 300,
              ),
              // Lottie.asset(
              //   "assets/animation/splash.json",
              //   width: 300,
              //   height: 300,
              // ),
              // Lottie.network(
              //   "https://lottie.host/5908647d-7a09-45c3-a6d6-5fb211fca0d7/M4woAvEArD.json",
              //   width: 200,
              //   height: 200,
              //   fit: BoxFit.cover,
              // ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 90), // Add padding to text
            child: const Text(
              "EventNest",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 25,
                fontFamily: "Roboto",
                color: Colors.deepPurple,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
