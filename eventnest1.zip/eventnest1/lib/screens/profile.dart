import 'package:eventnest1/admin/viewdata.dart' show ViewUserDataScreen;
import 'package:eventnest1/screens/signup.dart';
import 'package:eventnest1/services/auth.dart';
import 'package:eventnest1/services/shared_pref.dart';
import 'package:flutter/material.dart';
import 'package:eventnest1/screens/contact.dart';
import 'package:eventnest1/admin/userprofile.dart';
import '../admin/viewuserprofile.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> with SingleTickerProviderStateMixin {
  String? image, name, email, id;
  double _opacity = 0.0;

  @override
  void initState() {
    super.initState();
    getSharedPref();
    Future.delayed(const Duration(milliseconds: 400), () {
      setState(() {
        _opacity = 1.0;
      });
    });
  }

  Future<void> getSharedPref() async {
    id = await SharedpreferenceHelper().getUserId();
    image = await SharedpreferenceHelper().getUserImage();
    name = await SharedpreferenceHelper().getUserName();
    email = await SharedpreferenceHelper().getUserEmail();
    setState(() {});
  }

  Widget buildProfileTile(IconData icon, String title, String subtitle) {
    return AnimatedOpacity(
      opacity: _opacity,
      duration: const Duration(milliseconds: 600),
      child: Card(
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          leading: CircleAvatar(
            backgroundColor: Colors.deepPurple.shade50,
            child: Icon(icon, color: Colors.deepPurple),
          ),
          title: Text(title, style: const TextStyle(fontSize: 14, color: Colors.grey)),
          subtitle: Text(subtitle, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  Widget buildActionTile(String title, IconData icon, VoidCallback onTap, {Color iconColor = Colors.deepPurple}) {
    return AnimatedOpacity(
      opacity: _opacity,
      duration: const Duration(milliseconds: 700),
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          leading: CircleAvatar(
            backgroundColor: iconColor.withOpacity(0.15),
            child: Icon(icon, color: iconColor),
          ),
          title: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
          onTap: onTap,
        ),
      ),
    );
  }

  void showCustomSnackBar(String message, {Color backgroundColor = Colors.red}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.error_outline, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: backgroundColor,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Gradient background
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFa18cd1), Color(0xFFfbc2eb)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),

          // Main content
          AnimatedOpacity(
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
            opacity: _opacity,
            child: image == null
                ? const Center(child: CircularProgressIndicator())
                : Column(
              children: [
                Container(
                  padding: const EdgeInsets.only(top: 60, left: 20, right: 20, bottom: 30),
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF6C5CE7), Color(0xFFA29BFE)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                  ),
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 55,
                        backgroundImage: NetworkImage(image!),
                        backgroundColor: Colors.white,
                      ),
                      const SizedBox(height: 14),
                      Text(
                        name ?? "Guest",
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        email ?? "",
                        style: const TextStyle(fontSize: 14, color: Colors.white70),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 15),

                // Scrollable List Tiles
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        buildProfileTile(Icons.person, "Name", name ?? "N/A"),
                        buildProfileTile(Icons.email, "Email", email ?? "N/A"),

                        // buildActionTile("View Public Profile", Icons.person_pin, () {
                        //   if (name != null && email != null && id != null) {
                        //     Navigator.push(
                        //       context,
                        //       MaterialPageRoute(
                        //         builder: (context) => ViewUserDataScreen(
                        //           userId: id!,
                        //           name: name!,
                        //           email: email!,
                        //         ),
                        //       ),
                        //     );
                        //   }
                        // }, iconColor: Colors.indigo),

                        // buildActionTile("Edit Profile", Icons.edit, () {
                        //   if (id != null) {
                        //     Navigator.push(
                        //       context,
                        //       MaterialPageRoute(
                        //         builder: (context) => EditUserProfile(
                        //           userId: id!,
                        //           name: name!,
                        //           email: email!,
                        //         ),
                        //       ),
                        //     );
                        //   } else {
                        //     showCustomSnackBar("User ID not found. Please try again.");
                        //   }
                        // }, iconColor: Colors.blueAccent),

                        buildActionTile("Contact Us", Icons.support_agent, () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const ContactUs()),
                          );
                        }, iconColor: Colors.teal),

                        buildActionTile("Log Out", Icons.logout_rounded, () {
                          AuthMeathod().SignOut().then((_) {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => const Signup()),
                            );
                          });
                        }, iconColor: Colors.orange),

                        buildActionTile("Delete Account", Icons.delete_forever_rounded, () {
                          AuthMeathod().deletuser().then((_) {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => const Signup()),
                            );
                          });
                        }, iconColor: Colors.red),

                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
