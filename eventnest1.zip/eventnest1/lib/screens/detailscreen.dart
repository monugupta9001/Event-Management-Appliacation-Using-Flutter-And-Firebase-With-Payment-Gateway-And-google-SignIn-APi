import 'dart:convert';
import 'package:eventnest1/services/data.dart' show secretKey;
import 'package:eventnest1/services/database.dart';
import 'package:eventnest1/services/shared_pref.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:http/http.dart' as http;

class Detailscreen extends StatefulWidget {
  final String name, location, date, price, detail;

  Detailscreen({
    required this.date,
    required this.location,
    required this.name,
    required this.price,
    required this.detail,
  });

  @override
  State<Detailscreen> createState() => _DetailscreenState();
}

class _DetailscreenState extends State<Detailscreen> {
  Map<String, dynamic>? paymentIntent;
  int ticket = 1;
  int total = 0;
  String? name, image, id;

  @override
  void initState() {
    total = int.tryParse(widget.price) ?? 0;
    onTheLoad();
    super.initState();
  }

  Future<void> onTheLoad() async {
    name = await SharedpreferenceHelper().getUserName();
    image = await SharedpreferenceHelper().getUserImage();
    id = await SharedpreferenceHelper().getUserId();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Color(0xffe0c3fc),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xffe0c3fc), Color(0xff8ec5fc)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                      child: Image.asset(
                        "assets/images/event.jpg",
                        height: screenHeight * 0.45,
                        width: screenWidth,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Positioned(
                      top: 20,
                      left: 20,
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: CircleAvatar(
                          radius: 24,
                          backgroundColor: Colors.white.withOpacity(0.9),
                          child: Icon(Icons.arrow_back_ios_new_outlined, color: Color(0xFF6351EC)),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 30,
                      left: 20,
                      right: 20,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.name,
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              shadows: [Shadow(color: Colors.black54, blurRadius: 4)],
                            ),
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.calendar_today, color: Colors.white),
                              SizedBox(width: 6),
                              Text(widget.date, style: TextStyle(color: Colors.white)),
                              Spacer(),
                              Icon(Icons.location_on, color: Colors.white),
                              SizedBox(width: 6),
                              Flexible(
                                child: Text(widget.location,
                                    style: TextStyle(color: Colors.white),
                                    overflow: TextOverflow.ellipsis),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("About Event",
                          style: TextStyle(
                              fontSize: 24, fontWeight: FontWeight.w600, color: Color(0xff30384d))),
                      SizedBox(height: 12),
                      Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 4)),
                          ],
                        ),
                        child: Text(
                          widget.detail,
                          style: TextStyle(fontSize: 16, height: 1.6, color: Colors.grey[800]),
                        ),
                      ),
                      SizedBox(height: 30),
                      Text("Tickets",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xff30384d))),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          buildRoundButton(Icons.remove, Colors.redAccent, () {
                            if (ticket > 1) {
                              ticket--;
                              total -= int.tryParse(widget.price) ?? 0;
                              setState(() {});
                            }
                          }),
                          SizedBox(width: 20),
                          Text(
                            ticket.toString(),
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(width: 20),
                          buildRoundButton(Icons.add, Colors.green, () {
                            if (ticket < 9) {
                              ticket++;
                              total += int.tryParse(widget.price) ?? 0;
                              setState(() {});
                            }
                          }),
                        ],
                      ),
                      SizedBox(height: 30),
                      Container(
                        padding: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 6)),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Total: ₹$total",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xff6351ec))),
                            ElevatedButton(
                              onPressed: () => makePayment(total.toString()),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xff6351ec),
                                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child:
                              Text("Book Now", style: TextStyle(fontSize: 16, color: Colors.white)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildRoundButton(IconData icon, Color color, VoidCallback onPressed) {
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          width: 40,
          height: 40,
          alignment: Alignment.center,
          child: Icon(icon, color: Colors.white, size: 20),
        ),
      ),
    );
  }

  Future<void> makePayment(String amount) async {
    try {
      paymentIntent = await createPaymentIntent(amount, 'INR');
      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: paymentIntent!['client_secret'],
          style: ThemeMode.dark,
          merchantDisplayName: 'EventNest',
        ),
      );
      displayPaymentSheet(amount);
    } catch (e, s) {
      print('exception: $e$s');
    }
  }

  Future<void> displayPaymentSheet(String amount) async {
    try {
      await Stripe.instance.presentPaymentSheet().then((_) async {
        Map<String, dynamic> bookingdetail = {
          "Number": ticket.toString(),
          "Total": total.toString(),
          "Event": widget.name,
          "Location": widget.location,
          "Date": widget.date,
          "Price": widget.price,
          "Detail": widget.detail,
          "Name": name,
          "Image": image,
        };

        await DatabaseMeathod().addUserBooking(bookingdetail, id!);
        await DatabaseMeathod().addAdminTickets(bookingdetail);

        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            contentPadding: EdgeInsets.all(20),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 50),
                SizedBox(height: 16),
                Text("Payment Successful",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                Text("Your booking has been confirmed."),
              ],
            ),
          ),
        );

        paymentIntent = null;
      });
    } on StripeException {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          contentPadding: EdgeInsets.all(20),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.cancel, color: Colors.red, size: 50),
              SizedBox(height: 16),
              Text("Payment Cancelled",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              Text("Unfortunately, the payment was cancelled."),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  makePayment(total.toString());
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: Text("Retry Payment"),
              ),
            ],
          ),
        ),
      );
    } catch (_) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          contentPadding: EdgeInsets.all(20),
          content: Text("An unexpected error occurred. Please try again later."),
        ),
      );
    }
  }

  Future<Map<String, dynamic>?> createPaymentIntent(String amount, String currency) async {
    try {
      Map<String, dynamic> body = {
        'amount': calculateAmount(amount),
        'currency': currency,
        'payment_method_types[]': 'card',
      };

      var response = await http.post(
        Uri.parse('https://api.stripe.com/v1/payment_intents'),
        headers: {
          'Authorization': 'Bearer $secretKey',
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: body,
      );
      return jsonDecode(response.body);
    } catch (err) {
      print('error charging users: ${err.toString()}');
      return null;
    }
  }

  String calculateAmount(String amount) {
    final int priceValue = int.tryParse(amount) ?? 0;
    return (priceValue * 100).toString();
  }
}
