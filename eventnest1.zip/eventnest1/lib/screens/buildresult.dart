import 'package:flutter/material.dart';

class BuildResultCard extends StatelessWidget {
  final Map<String, dynamic> eventData;

  const BuildResultCard({Key? key, required this.eventData}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: Icon(Icons.event, color: Colors.blue),
        title: Text(
          eventData['UpdatedName'] ?? 'No Name',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          eventData['Description'] ?? 'No Description Available',
          style: TextStyle(fontSize: 14, color: Colors.grey),
        ),
        trailing: Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
        onTap: () {
          // Handle event click action
          print("Event selected: ${eventData['UpdatedName']}");
          // You can navigate to another screen with event details
        },
      ),
    );
  }
}
