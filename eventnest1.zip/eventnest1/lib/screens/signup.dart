import 'package:eventnest1/admin/adminSignup.dart';
import 'package:eventnest1/services/auth.dart';
import 'package:flutter/material.dart';

class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              SizedBox(height: 40),

              // Event Image
              Image.asset("assets/images/onboarding.png"),
              SizedBox(height: 20),

              // Title Text
              Text(
                "Unlock The Feature Of",
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.w600,
                  fontSize: 28,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "Event Booking App",
                style: TextStyle(
                  color: Color(0xff6351ec),
                  fontWeight: FontWeight.bold,
                  fontSize: 32,
                ),
              ),
              SizedBox(height: 20),

              // Subheading Text
              Text(
                "Discover, book, and experience \nthe best events around you",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black45, fontSize: 18),
              ),
              SizedBox(height: 40),

              // Sign In with Google Button
              GestureDetector(
                onTap: () {
                  AuthMeathod().signInWithGoogle(context);
                },
                child: Container(
                  height: 60,
                  decoration: BoxDecoration(
                    color: Color(0xff6351ec),
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        offset: Offset(0, 4),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        "assets/images/google.png",
                        height: 30,
                        width: 30,
                        fit: BoxFit.cover,
                      ),
                      SizedBox(width: 20),
                      Text(
                        "Sign In with Google",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 30),

              // Admin Signup Link
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Adminsignup()),
                  );
                },
                child: Text(
                  "Sign Up As Admin",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Colors.black,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
              SizedBox(height: 40),

              // Optional: Additional Information or Button (e.g., Terms and Conditions)
              TextButton(
                onPressed: () {
                  // Navigate to terms and conditions
                },
                child: Text(
                  "By signing up, you agree to our Terms & Conditions",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black54, fontSize: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
