import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:eventnest1/screens/detailscreen.dart';
import 'package:eventnest1/screens/profile.dart';
import 'package:eventnest1/services/database.dart' show DatabaseMeathod;
import 'package:eventnest1/services/shared_pref.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';

import '../services/searchdelegate.dart' show EventSearchDelegate;
import 'alleventscreen.dart';
import 'catageries.dart' show Catageries;

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Stream? eventStream;
  String location = "Fetching location...";
  String shortLocation = "Loading...";
  bool search = false;
  List<QueryDocumentSnapshot> searchResults = [];
  TextEditingController searchController = TextEditingController();
  String userName = "Guest";
  String? userImage;
  bool isLoadingLocation = true;
  bool isLoadingEvents = true;

  // Enhanced color scheme
  final Color primaryColor = const Color(0xFF6C5CE7);
  final Color primaryLight = const Color(0xFFA29BFE);
  final Color primaryDark = const Color(0xFF4834D4);
  final Color secondaryColor = const Color(0xFFFD79A8);
  final Color accentColor = const Color(0xFF00CEFF);
  final Color successColor = const Color(0xFF00B894);
  final Color backgroundColor = const Color(0xFFF8F9FF);
  final Color cardColor = const Color(0xFFFFFFFF);
  final Color textPrimary = const Color(0xFF2D3436);
  final Color textSecondary = const Color(0xFF636E72);
  final Color shimmerBase = const Color(0xFFE0E0E0);
  final Color shimmerHighlight = const Color(0xFFF5F5F5);

  @override
  void initState() {
    super.initState();
    ontheload();
    _getCurrentLocation();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    String? name = await SharedpreferenceHelper().getUserName();
    String? image = await SharedpreferenceHelper().getUserImage();
    if (mounted) {
      setState(() {
        userName = name ?? "Guest";
        userImage = image;
      });
    }
  }

  ontheload() async {
    eventStream = await DatabaseMeathod().getallEvents();
    setState(() {
      isLoadingEvents = false;
    });
  }

  Future<void> _getCurrentLocation() async {
    try {
      setState(() => isLoadingLocation = true);

      bool serviceEnabled;
      LocationPermission permission;

      serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() {
          location = "Location services are disabled.";
          shortLocation = "Unknown";
          isLoadingLocation = false;
        });
        return;
      }

      permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          setState(() {
            location = "Location permission denied.";
            shortLocation = "Permission denied";
            isLoadingLocation = false;
          });
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        setState(() {
          location = "Location permission permanently denied.";
          shortLocation = "Permission denied";
          isLoadingLocation = false;
        });
        return;
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() {
        location =
            "📍 Latitude: ${position.latitude}, Longitude: ${position.longitude}\nFetching address...";
        shortLocation = "Locating...";
      });

      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      ).timeout(const Duration(seconds: 10));

      Placemark place = placemarks.isNotEmpty ? placemarks[0] : Placemark();

      setState(() {
        location =
            "${place.locality}, ${place.administrativeArea}, ${place.country}";
        shortLocation = place.locality ?? place.administrativeArea ?? "Nearby";
        isLoadingLocation = false;
      });
    } catch (e) {
      setState(() {
        location = "Error fetching location: ${e.toString()}";
        shortLocation = "Unknown";
        isLoadingLocation = false;
      });
    }
  }

  Widget _buildCategoryItem(String category, String imagePath, Color color) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: Animate(
        effects: [ScaleEffect(duration: 300.ms)],
        child: Container(
          margin: const EdgeInsets.only(right: 15),
          child: Material(
            elevation: 4,
            borderRadius: BorderRadius.circular(20),
            shadowColor: color.withOpacity(0.3),
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () {
                Navigator.push(
                  context,
                  PageRouteBuilder(
                    transitionDuration: Duration(milliseconds: 500),
                    pageBuilder:
                        (context, animation, secondaryAnimation) =>
                            Catageries(eventcategory: category),
                    transitionsBuilder: (
                      context,
                      animation,
                      secondaryAnimation,
                      child,
                    ) {
                      return FadeTransition(opacity: animation, child: child);
                    },
                  ),
                );
              },
              onHighlightChanged: (value) {
                setState(() {});
              },
              child: Container(
                width: 120,
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [color.withOpacity(0.1), color.withOpacity(0.3)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: color.withOpacity(0.2),
                            blurRadius: 6,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Image.asset(
                        imagePath,
                        height: 28,
                        width: 28,
                        color: color,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      category,
                      style: TextStyle(
                        color: textPrimary,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEventCard(DocumentSnapshot ds) {
    dynamic dateData = ds["date"];
    DateTime parsedDate;

    if (dateData is Timestamp) {
      parsedDate = dateData.toDate();
    } else if (dateData is String) {
      parsedDate = DateTime.tryParse(dateData) ?? DateTime.now();
    } else {
      return Container();
    }

    String formattedDate = DateFormat('MMM dd').format(parsedDate);
    DateTime currentDate = DateTime.now();
    bool hasPassed = parsedDate.isBefore(currentDate);

    if (hasPassed) return Container();

    return Animate(
      effects: [
        FadeEffect(duration: 300.ms),
        SlideEffect(begin: Offset(0, 0.1)),
      ],
      child: Container(
        margin: const EdgeInsets.only(bottom: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 15,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () {
              Navigator.push(
                context,
                PageRouteBuilder(
                  transitionDuration: Duration(milliseconds: 500),
                  pageBuilder:
                      (context, animation, secondaryAnimation) => Detailscreen(
                        date:
                            dateData is Timestamp
                                ? dateData.toDate().toString()
                                : dateData,
                        detail: ds["detail"],
                        location: ds["location"],
                        name: ds["name"],
                        price: ds["price"],
                      ),
                  transitionsBuilder: (
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ) {
                    var curve = Curves.easeInOut;
                    var tween = Tween(
                      begin: 0.0,
                      end: 1.0,
                    ).chain(CurveTween(curve: curve));
                    return FadeTransition(
                      opacity: animation.drive(tween),
                      child: child,
                    );
                  },
                ),
              );
            },
            highlightColor: primaryColor.withOpacity(0.1),
            splashColor: primaryColor.withOpacity(0.2),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Event Image + Date Label
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                      child: Container(
                        height: 200,
                        width: double.infinity,
                        child: Image.asset(
                          "assets/images/event.jpg",
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 12,
                      left: 12,
                      child: Animate(
                        effects: [ScaleEffect(duration: 200.ms)],
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.white.withOpacity(0.95),
                                Colors.white.withOpacity(0.85),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(30),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 6,
                                offset: Offset(1, 2),
                              ),
                            ],
                          ),
                          child: Text(
                            formattedDate,
                            style: TextStyle(
                              color: primaryColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                // Event Info Section
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: cardColor,
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(20),
                      bottomRight: Radius.circular(20),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title and Price
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              ds["name"],
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: textPrimary,
                              ),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                          Text(
                            "₹${ds["price"]}",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: primaryColor,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),

                      // Location
                      Row(
                        children: [
                          Icon(
                            Icons.location_on,
                            size: 18,
                            color: textSecondary,
                          ),
                          const SizedBox(width: 5),
                          Expanded(
                            child: Text(
                              ds["location"],
                              style: TextStyle(
                                fontSize: 14,
                                color: textSecondary,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildShimmerEventCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Shimmer.fromColors(
        baseColor: shimmerBase,
        highlightColor: shimmerHighlight,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Shimmer image placeholder
            Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
            ),
            // Shimmer content placeholder
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    height: 20,
                    color: Colors.white,
                  ),
                  SizedBox(height: 8),
                  Container(width: 100, height: 20, color: Colors.white),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget allEvents() {
    return StreamBuilder(
      stream: eventStream,
      builder: (context, AsyncSnapshot snapshot) {
        if (search) return Container();

        if (isLoadingEvents || !snapshot.hasData) {
          return Column(
            children: List.generate(3, (index) => _buildShimmerEventCard()),
          );
        }

        if (snapshot.data.docs.isEmpty) {
          return Column(
            children: [
              SizedBox(height: 40),
              Image.asset(
                'assets/images/no_events.png',
                height: 150,
                width: 150,
              ),
              SizedBox(height: 20),
              Text(
                "No upcoming events",
                style: TextStyle(
                  fontSize: 18,
                  color: textSecondary,
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "Check back later or explore other categories",
                style: TextStyle(
                  fontSize: 14,
                  color: textSecondary.withOpacity(0.7),
                ),
                textAlign: TextAlign.center,
              ),
            ],
          );
        }

        return Column(
          children:
              snapshot.data.docs
                  .map<Widget>((ds) => _buildEventCard(ds))
                  .toList(),
        );
      },
    );
  }

  Widget _buildProfileButton() {
    return Animate(
      effects: [ScaleEffect(duration: 200.ms)],
      child: Container(
        height: 42,
        width: 42,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white.withOpacity(0.5), width: 2),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          shape: const CircleBorder(),
          child: InkWell(
            borderRadius: BorderRadius.circular(30),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const Profile(),
                  fullscreenDialog: true,
                ),
              );
            },
            child: ClipOval(
              child:
                  userImage != null && userImage!.isNotEmpty
                      ? Image.network(
                        userImage!,
                        fit: BoxFit.cover,
                        errorBuilder:
                            (context, error, stackTrace) => Icon(
                              Icons.person_outline,
                              color: Colors.white,
                              size: 22,
                            ),
                      )
                      : Center(
                        child: Icon(
                          Icons.person_outline,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLocationShimmer() {
    return Shimmer.fromColors(
      baseColor: Colors.white.withOpacity(0.3),
      highlightColor: Colors.white.withOpacity(0.5),
      child: Container(
        width: 150,
        height: 20,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background gradient with animated elements
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [backgroundColor, Color(0xFFE6E9FF), Color(0xFFD6DAFF)],
                stops: [0.1, 0.5, 0.9],
              ),
            ),
          ),

          // Floating decorative elements
          Positioned(
            top: -50,
            right: -50,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [primaryColor.withOpacity(0.1), Colors.transparent],
                ),
              ),
            ),
          ),

          Positioned(
            bottom: -100,
            left: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [secondaryColor.withOpacity(0.1), Colors.transparent],
                ),
              ),
            ),
          ),

          // Scrollable content
          SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            padding: EdgeInsets.only(top: 100), // Space for fixed header
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height:25),
                  // Welcome section
                  Animate(
                    effects: [FadeEffect(duration: 300.ms)],
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RichText(
                          text: TextSpan(
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                              color: textPrimary,
                              height: 1.3,
                            ),
                            children: [
                              TextSpan(text: "Hello, "),
                              TextSpan(
                                text: userName,
                                style: TextStyle(color: primaryColor),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          "Discover amazing events near you",
                          style: TextStyle(fontSize: 16, color: textSecondary),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 25),

                  // Search bar with animation
                  Animate(
                    effects: [
                      SlideEffect(
                        begin: Offset(0, 10),
                        duration: 400.ms,
                        curve: Curves.easeOutQuart,
                      ),
                      FadeEffect(duration: 400.ms),
                    ],
                    child: GestureDetector(
                      onTap: () {
                        showSearch(
                          context: context,
                          delegate: EventSearchDelegate(),
                        );
                      },
                      child: Hero(
                        tag: 'search_bar',
                        child: Material(
                          color: Colors.transparent,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(
                                  color: primaryColor.withOpacity(0.1),
                                  blurRadius: 15,
                                  offset: Offset(0, 5),
                                ),
                              ],
                            ),
                            padding: EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 15,
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.search,
                                  color: primaryColor,
                                  size: 26,
                                ),
                                SizedBox(width: 10),
                                Text(
                                  "Search events...",
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: 30),

                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Categories section
                      Animate(
                        effects: [FadeEffect(duration: 300.ms)],
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Categories",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: textPrimary,
                              ),
                            ),
                            SizedBox(height: 20),
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              physics: BouncingScrollPhysics(),
                              child: Row(
                                children: [
                                  _buildCategoryItem(
                                    "Music",
                                    "assets/images/musical.png",
                                    primaryColor,
                                  ),
                                  _buildCategoryItem(
                                    "Clothing",
                                    "assets/images/tshirt.png",
                                    secondaryColor,
                                  ),
                                  _buildCategoryItem(
                                    "Festival",
                                    "assets/images/confetti.png",
                                    accentColor,
                                  ),
                                  _buildCategoryItem(
                                    "Food",
                                    "assets/images/dish.png",
                                    successColor,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      SizedBox(height: 30),

                      // Upcoming Events section
                      Animate(
                        effects: [FadeEffect(duration: 300.ms)],
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Upcoming Events",
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: textPrimary,
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder:
                                            (context) => AllEventsScreen(
                                              eventStream:
                                                  FirebaseFirestore.instance
                                                      .collection('Event')
                                                      .snapshots(),
                                              primaryColor: primaryColor,
                                              textColor: textPrimary,
                                            ),
                                      ),
                                    );
                                  },
                                  child: Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      color: primaryColor.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Row(
                                      children: [
                                        Text(
                                          "See all",
                                          style: TextStyle(
                                            color: primaryColor,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        SizedBox(width: 5),
                                        Icon(
                                          Icons.arrow_forward,
                                          size: 16,
                                          color: primaryColor,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 15),
                            allEvents(),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Fixed header with location
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Animate(
              effects: [FadeEffect(duration: 200.ms)],
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [primaryDark, primaryColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 10,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: SafeArea(
                  child: Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [primaryColor.withOpacity(0.9), primaryLight],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(10),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: primaryColor.withOpacity(0.3),
                          blurRadius: 15,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // Location icon
                        Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.location_pin,
                            color: Colors.white,
                            size: 22,
                          ),
                        ),
                        SizedBox(width: 10),
                        // Location text
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "CURRENT LOCATION",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.white.withOpacity(0.8),
                                  fontWeight: FontWeight.w500,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              SizedBox(height: 4),
                              isLoadingLocation
                                  ? _buildLocationShimmer()
                                  : Text(
                                    shortLocation,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                            ],
                          ),
                        ),
                        // Profile button
                        _buildProfileButton(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),

      // Floating action button for quick actions
      // floatingActionButton: FloatingActionButton(
      //       onPressed: () {
      //         // Add quick action functionality
      //       },
      //       backgroundColor: primaryColor,
      //       elevation: 4,
      //       child: Icon(Icons.add, color: Colors.white),
      //     )
      //     .animate(onPlay: (controller) => controller.repeat(reverse: true))
      //     .moveY(begin: 10, end: 0, duration: 1000.ms, curve: Curves.easeInOut),
    );
  }
}
