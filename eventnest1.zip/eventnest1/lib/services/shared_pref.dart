import 'package:shared_preferences/shared_preferences.dart';

class SharedpreferenceHelper {
  // Keys for SharedPreferences
  String userIdkey = "USERKEY";
  String userNamekey = "USERNAMEKEY";
  String userEmailkey = "USEREMAILKEY";
  String userImagekey = "USERIMAGEKEY";

  // Save individual user data fields
  Future<bool> saveUserId(String getUserId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(userIdkey, getUserId);
  }

  Future<bool> saveUserName(String getUserName) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(userNamekey, getUserName);
  }

  Future<bool> saveUserEmail(String getUserEmail) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(userEmailkey, getUserEmail);
  }

  Future<bool> saveUserImage(String getUserImage) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(userImagekey, getUserImage);
  }

  // Save all user data at once
  Future<void> saveUser(Map<String, String> userData) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('userId', userData['userId']!);
    prefs.setString('userName', userData['userName']!);
    prefs.setString('userEmail', userData['userEmail']!);
    prefs.setString('userImage', userData['userImage']!);
  }

  // Get individual user data fields
  Future<String?> getUserId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(userIdkey);
  }

  Future<String?> getUserName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(userNamekey);
  }

  Future<String?> getUserEmail() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(userEmailkey);
  }

  Future<String?> getUserImage() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(userImagekey);
  }

  // Fetch all user data as a Map
  Future<Map<String, String?>> getUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return {
      'userId': prefs.getString(userIdkey) ?? null,
      'userName': prefs.getString(userNamekey) ?? null,
      'userEmail': prefs.getString(userEmailkey) ?? null,
      'userImage': prefs.getString(userImagekey) ?? null,
    };
  }

  // To clear the stored data (Optional)
  Future<bool> clearUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.clear();  // Clears all saved data in SharedPreferences
  }
}
