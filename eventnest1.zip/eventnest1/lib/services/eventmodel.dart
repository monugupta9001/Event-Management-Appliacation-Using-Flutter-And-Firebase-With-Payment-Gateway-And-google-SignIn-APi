class EventModel {
  final String name;
  final String location;
  final String date;
  final String price;
  final String detail;

  EventModel({
    required this.name,
    required this.location,
    required this.date,
    required this.price,
    required this.detail,
  });

  factory EventModel.fromMap(Map<String, dynamic> map) {
    return EventModel(
      name: map['name'] ?? '',
      location: map['location'] ?? '',
      date: map['date'] ?? '',
      price: map['price'] ?? '0',
      detail: map['detail'] ?? '',
    );
  }
}
