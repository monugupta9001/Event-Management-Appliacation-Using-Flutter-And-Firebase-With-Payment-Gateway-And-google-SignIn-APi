import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseMeathod {
  Future addUserDetail(Map<String, dynamic> userInfoMap, String id) async {
    return await FirebaseFirestore.instance
        .collection("users")
        .doc(id)
        .set(userInfoMap);
  }

  Future addEvent(Map<String, dynamic> userInfoMap, String id) async {
    return await FirebaseFirestore.instance
        .collection("Event")
        .doc(id)
        .set(userInfoMap);
  }

  Future<Stream<QuerySnapshot>> getallEvents() async {
    return FirebaseFirestore.instance.collection("Event").snapshots();
  }

  Future addUserBooking(Map<String, dynamic> userInfoMap, String id) async {
    return await FirebaseFirestore.instance
        .collection("users")
        .doc(id)
        .collection("Booking")
        .add(userInfoMap);
  }

  Future addAdminTickets(Map<String, dynamic> userInfoMap) async {
    return await FirebaseFirestore.instance
        .collection("Tickets")
        .add(userInfoMap);
  }

  Future<Stream<QuerySnapshot>> getbookings(String id) async {
    return FirebaseFirestore.instance
        .collection("users")
        .doc(id)
        .collection("Booking")
        .snapshots();
  }

  Future<Stream<QuerySnapshot>> getTickets() async {
    return FirebaseFirestore.instance.collection("Tickets").snapshots();
  }

  Future<Stream<QuerySnapshot>> getEventCategory(
    String id,
    String category,
  ) async {
    return FirebaseFirestore.instance
        .collection("Event")
        .where("category", isEqualTo: category)
        .snapshots();
  }

  Future<QuerySnapshot> search(String query) async {
    return await FirebaseFirestore.instance
        .collection('events')
        .where('name', isGreaterThanOrEqualTo: query)
        .where('name', isLessThan: query + 'z')
        .get();
  }

  // ✅ New Method: Fetch user data by ID
  Future<Map<String, dynamic>?> getUserData(String userId) async {
    try {
      DocumentSnapshot<Map<String, dynamic>> userDoc =
          await FirebaseFirestore.instance
              .collection("users")
              .doc(userId)
              .get();

      if (userDoc.exists && userDoc.data() != null) {
        final userData = userDoc.data()!;
        print("Fetched User Data for $userId: $userData");
        return userData;
      } else {
        print("User document does not exist for ID: $userId");
        return null;
      }
    } catch (e) {
      print("Error fetching user data for $userId: $e");
      return null;
    }
  }

  // Delete User from Firestore
  Future<void> deleteUser(String userId) async {
    try {
      await FirebaseFirestore.instance.collection("users").doc(userId).delete();
    } catch (e) {
      print("Error deleting user: $e");
    }
  }

  // ✅ New Method: Update User in Firestore
  Future<void> updateUser(
    String userId,
    Map<String, dynamic> updatedData,
  ) async {
    try {
      // Reference to the user document in Firestore
      DocumentReference userRef = FirebaseFirestore.instance
          .collection("users")
          .doc(userId);

      // Update the user document with the provided data
      await userRef.update(updatedData);

      print("User updated successfully: $userId");
    } catch (e) {
      print("Error updating user data for $userId: $e");
    }
  }
}
